package org.savefileapi.service;

import lombok.extern.slf4j.Slf4j;

import org.savefileapi.dao.FileEntity;
import org.savefileapi.dao.FileRepository;
import org.savefileapi.model.FileResponse;
import org.savefileapi.model.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;

@Service
@Slf4j
public class AdminService {

    @Autowired
    FileRepository fileRepository;

    public long saveFile(MultipartFile file) throws IOException {

        Random random = new Random();
        long key = random.nextInt(999999);

        FileEntity fileEntity = FileEntity.builder().fileName(file.getOriginalFilename()).fileData(file.getBytes()).type(file.getContentType()).securedKey(String.valueOf(key)).build();
        fileRepository.save(fileEntity);

        return key;

    }

    public byte[] getFile(int fileId, long securedKey) {
        Optional<FileEntity> file = fileRepository.findById(fileId);
        if (file.isPresent()) {
            if (file.get().getSecuredKey().equals(Long.toString(securedKey))) {
                return file.get().getFileData();
            } else {
                return "Key is incorrect".getBytes();
            }
        } else if (!file.isPresent()) {
            return "File not found".getBytes();
        }
        return null;
    }

    public ResponseEntity<Response> deleteFile(int fileId) {
        ResponseEntity<Response> responseResponseEntity;
        if (fileRepository.existsById(fileId)) {
            fileRepository.deleteById(fileId);
            responseResponseEntity = ResponseEntity.ok(Response.builder().httpStatusCode(String.valueOf(HttpStatus.OK)).message("File deleted successfully").build());
        } else {
            responseResponseEntity = ResponseEntity.badRequest().body(Response.builder().errorCode(String.valueOf(HttpStatus.BAD_REQUEST.value())).message("File not found").build());
        }

        return responseResponseEntity;
    }

    public List<FileResponse> getAllFiles() {

        List<FileResponse> fileResponses = new ArrayList<>();

        List<FileEntity> fileEntities = fileRepository.findAll();
        if (!Objects.nonNull(fileEntities)) {
            return Collections.emptyList();
        }
        for (FileEntity list : fileEntities) {
            FileResponse response = FileResponse.builder().fileId(list.getId()).
                    fileName(list.getFileName()).fileType(list.getType()).build();
            fileResponses.add(response);
        }
        return fileResponses;

    }
}
