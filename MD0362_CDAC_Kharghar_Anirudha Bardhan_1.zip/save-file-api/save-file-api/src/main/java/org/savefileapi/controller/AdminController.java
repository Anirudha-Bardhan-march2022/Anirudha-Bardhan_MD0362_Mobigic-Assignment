package org.savefileapi.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.savefileapi.model.FileResponse;
import org.savefileapi.model.Response;
import org.savefileapi.service.AdminService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;


@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping("/operate-file")
public class AdminController {


    private final AdminService adminService;

    @PostMapping("/save-file")
    public long uploadFile(@RequestParam("file") MultipartFile file) throws IOException {

        long key = adminService.saveFile(file);
        log.info("StudentController.save finished successfully");
        return key;
    }

    @GetMapping("/files")
    public List<FileResponse> getAllFiles() {
        return adminService.getAllFiles();
    }

    @GetMapping("/file/{fileId}/{securedKey}")
    public byte[] getFile(@PathVariable("fileId") int fileId, @PathVariable("securedKey") long securedKey) {
        return adminService.getFile(fileId, securedKey);

    }

    @DeleteMapping("/delete-file/{fileId}")
    public ResponseEntity<Response> deleteFile(@PathVariable("fileId") int fileId) {
        return adminService.deleteFile(fileId);

    }
}
