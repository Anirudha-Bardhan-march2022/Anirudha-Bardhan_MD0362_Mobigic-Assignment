package org.savefileapi.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.savefileapi.dao.user.User;
import org.savefileapi.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@CrossOrigin
@RestController
@RequiredArgsConstructor
@Slf4j
@RequestMapping("/user")
public class UserController {


    private final UserService userService;

    //find user in database authenticate identity of that user if password matches with database password then
    //and only then give  access.
    @PostMapping("/user-login")
    public Object authenticateUser(@RequestBody User cred) {
        return userService.authenticateUser(cred.getUserName(), cred.getPassword());
    }

    @PostMapping("/save-user")
    public ResponseEntity<?> saveUser(@RequestBody User user) {
        return userService.saveUser(user);
    }

}
