package org.savefileapi.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FileResponse {

    private String fileName;

    private String fileType;

    private int fileId;

}
