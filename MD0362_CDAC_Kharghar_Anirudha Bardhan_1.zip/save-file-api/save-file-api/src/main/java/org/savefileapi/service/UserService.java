package org.savefileapi.service;

import java.util.Objects;

import lombok.RequiredArgsConstructor;
import org.savefileapi.dao.UserRepository;
import org.savefileapi.dao.user.User;
import org.savefileapi.model.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Transactional
@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;


    @Autowired
    PasswordEncoder passwordEncoder;

    public ResponseEntity<Response> saveUser(User user) {

        if (Objects.nonNull(user)) {
            String encPassword = passwordEncoder.encode(user.getPassword());
            user.setPassword(encPassword);
            userRepository.save(user);
            return ResponseEntity.ok(Response.builder().httpStatusCode(
                    String.valueOf(HttpStatus.OK.value())).httpStatusCode("User saved").build());
        }
        return ResponseEntity.badRequest().body(Response.builder().errorCode(String.valueOf(HttpStatus.BAD_REQUEST.value())).
                message("Entity couldn't be able to save").build());
    }


    public String authenticateUser(String userName, String password) {
        User user = userRepository.findByUserName(userName);
        if (Objects.nonNull(user) && passwordEncoder.matches(password, user.getPassword())) {

            return user.getUserName();
        }
        return "Login unsuccessful: Password or Username does not match";
    }
}